let rooms = 2// how many rooms are in the gallery
let gallery_rooms = [] //where the class objects are stored, which is each room in gallery with its attributes
let gallery_room_number = 0

//each button has text, position x, y
let buttons_mode1 =[]
let mode1 = false, mode2 = false, mode3 = false 

let canvasHeight;

let shagn;
let shagv;

let sounds  = []


function preload(){
  for (let i = 0; i < rooms; i++){
    let galleryR = loadImage ("assets/galleryR" + i + ".jpg")
    let dressN = loadImage ("assets/dressN" + i +".png")

    gallery_rooms.push (new Gallery (galleryR, dressN, i))
  }

  shagv = loadSound ("assets/step_forward.mp3")
  shagv.setVolume (0.4)

  shagn = loadSound ("assets/step_back.mp3")
  shagn.setVolume (0.4)

  sounds.push (shagv, shagn)
// /////////delete after implementing
//   img = loadImage ("assets/666.png")

// ///////////

}

function setup() {
  let imgw = 3840;
  let imgh = 2160;
  let ratio1 = imgh/imgw;
  canvasHeight = windowWidth * ratio1

  let canvas = createCanvas(windowWidth, canvasHeight);
  canvas.parent("p5-canvas-container");

  // buttons
  let buttonA = new Buttons (1, windowWidth/10, windowHeight/10, "Get to know more")
  buttons_mode1.push (buttonA)

 


}

function draw() {
  background(220);

  push ()
  translate (width/2, height/2)

  

  gallery_rooms[gallery_room_number].display()
  gallery_rooms[gallery_room_number].update()

  
  
  for (i=0; i < buttons_mode1.length; i++){
      buttons_mode1[i].display()
    }
  



  
  

  // console.log (gallery_rooms[gallery_room_number].steps)

  pop()



/// if the mode1
/// only 1 button 

//if the mode 2 + button on the left 
//4 buttons 

// if the mode 3 + button on the left 
// change background - take a photo - save to the gallery
  
}

//button get to know more
class Buttons {
  constructor(modeN, x, y, value){
   this.mode = modeN
   this.button_positionX = x
   this.button_positionY = y
   this.value = value
  }
  
  display (){
    for (i= 0; i < this.button_group.length; i++){
      let button = createButton (this.value)
      button.position (this.button_positionX, this.button_positionY)
    }
     
  }

  update (){
  
     
    }
  }









class Gallery {
  constructor (galleryR, dressN, roomNumber){
  this.galleryRoomImage = galleryR
  this.dressExhibit = dressN
  this.galleryRoomNumber = roomNumber
  this.steps = 0
  this.picture_scale = 1
}

display(){
  scale (this.picture_scale)
  image (this.galleryRoomImage, -windowWidth/2, -canvasHeight/2, windowWidth, canvasHeight)
  
  // let offsetX = map (mouseX, 0, windowWidth, 10, -10)
  // let offsetY = map (mouseY, 0, canvasHeight, 10, -10)
  drawingContext.shadowOffsetX = 5
  drawingContext.shadowOffsetY = 5
  drawingContext.shadowBlur = 10;
  drawingContext.shadowColor = "white"
  image (this.dressExhibit, -windowWidth/2, -canvasHeight/2, windowWidth, canvasHeight)

  fill("red");
  circle(0, 0, 5)

}

update (){
  if (keyIsPressed == true && key == "ArrowUp"){

    this.picture_scale += 0.005

    if (this.steps <= 200) {
      this.steps += 1
    }
    
    if (shagn.isPlaying()==false && shagv.isPlaying() == false){
      random (sounds).play()
    }
    

  }else if (keyIsPressed == true && key == "ArrowDown"){

    if (this.picture_scale > 1){

      this.picture_scale -= 0.01

      if (shagn.isPlaying()==false && shagv.isPlaying() == false){
        random(sounds).play()
      }
    }
      
    if (this.steps >= 0) {
      this.steps -= 1
      }

  
  }

  if (this.steps > 200){
    gallery_room_number += 1
  }

  if (this.steps < 0){
    gallery_room_number -= 1
  }


  
  }


}


  




